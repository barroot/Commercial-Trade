package commercialtrading;
import java.util.Random;

/**
* @author Luis, Marcionedes, Michael
* @version 2.0
* @since 2018-04-11
 */
public class CompanyA implements Company{
    
    int id = 1; //sets a start point for depots id
    Random rn = new Random(); // instantiates the random library
    private int stockA = rn.nextInt(35)+15; // Stores a random number between 15 & 50
    private int stockB = rn.nextInt(37)+3; // Stores a random number between 3 & 40
    private int stockC = rn.nextInt(37)+3; // Stores a random number between 3 & 40
    private int allowance = rn.nextInt(50)+50; // Stores a random number between 50 & 100
    private final int productCost = rn.nextInt(9)+1; // Stores a random number between 1 & 10
    private final int delivery = rn.nextInt(9)+1; // Stores a random number between 1 & 10

     
    /**
     * 
     * @param id first arg
     */
    public CompanyA(int id){
        this.id = id;
    }
    
     /**
     * @return id, stockA, stockB, stockC, allowance, productCost, delivery
     * 
     */
    @Override
    public String toString() {
        
        return  "ID :"+ id +"\n"+
                "stock A: " +stockA+"\n"+
                "stock B: "+stockB+"\n"+
                "stock C: "+stockC+"\n"+
                "Allowance: "+allowance+"\n"+
                "Product cost: "+productCost+"\n"+
                "Delivery Cost: "+delivery+"\n";
      
    }
   
    /**
     * @return the stockA
     */
    public int getStockA() {
        return stockA;
    }

    /**
     * @param stockA the stockA to set
     */
    public void setStockA(int stockA) {
        this.stockA = stockA;
    }

    /**
     * @return the stockB
     */
    public int getStockB() {
        return stockB;
    }

    /**
     * @param stockB the stockB to set
     */
    public void setStockB(int stockB) {
        this.stockB = stockB;
    }

    /**
     * @return the stockC
     */
    public int getStockC() {
        return stockC;
    }

    /**
     * @param stockC the stockC to set
     */
    public void setStockC(int stockC) {
        this.stockC = stockC;
    }

    /**
     * @return the allowance
     */
    public int getAllowance() {
        return allowance;
    }

    /**
     * @param allowance the allowance to set
     */
    public void setAllowance(int allowance) {
        this.allowance = allowance;
    }

    /**
     * @return the productCost
     */
    public int getProductCost() {
        return productCost;
    }

    /**
     * @return the delivery
     */
    public int getDelivery() {
        return delivery;
    }

}
