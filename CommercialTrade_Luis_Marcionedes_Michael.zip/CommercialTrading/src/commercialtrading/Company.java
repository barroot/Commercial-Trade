package commercialtrading;

/** 
*
* @author Luis, Marcionedes, Michael
* @version 2.0
* @since 2018-04-11
*/
public interface Company{
    
    /**
     *
     */
    int minN=15; //Variable setting the minimum native product for each depot

    /**
     *
     */
    int maxN=50; //Variable setting the maximum native product for each depot

    /**
     *
     */
    int minP=3; //Variable setting the minimum foreing product for each depot

    /**
     *
     */
    int maxP=40; //Variable setting the maximum foreing product for each depot
    
   
}
