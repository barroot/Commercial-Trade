package commercialtrading;
/**
 * Applying the design pattern: Facade Pattern
*
* @author Luis, Marcionedes, Michael
* @version 2.0
* @since 2018-04-11
 */
public class CommercialTradeFacade {

    /**
     *
     */
    public CommercialTradeFacade(){
       
        DepotFactory.addDepotsA(); //Populates array depotsA with 100 depots from collection CompanyA
        DepotFactory.addDepotsB(); //Populates array depotsB with 100 depots from collection CompanyB
        DepotFactory.addDepotsC(); //Populates array depotsC with 100 depots from collection CompanyC
        
        
        
        
        MenuSingleton instance = MenuSingleton.getInstance(); //Creates a variable to receive the method getInstance from MenuSingleton
        System.out.println(instance.welcome);
        instance.menu(); //Uses the method menu from MenuSingleton
        
        
        
        }
}
