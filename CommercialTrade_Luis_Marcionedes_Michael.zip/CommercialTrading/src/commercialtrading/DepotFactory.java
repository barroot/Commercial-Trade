package commercialtrading;

import java.util.ArrayList;
import java.util.List;

/**
 * Applying the design pattern: Factory Pattern
 * 
 * 
* @author Luis, Marcionedes, Michael
* @version 2.0
* @since 2018-04-11
 */
public class DepotFactory{
    
    static List<CompanyA> depotsA; // Creates a variable to store depots from collection/type Company(A)
    static List<CompanyB> depotsB; // Creates a variable to store depots from collection/type Company(B)  
    static List<CompanyC> depotsC; // Creates a variable to store depots from collection/type Company(C)
   
    /**
     * Populates ArrayList depotsA with 100 depots from collection CompanyA
     * @return depotsA
     */
  
    public static List<CompanyA> addDepotsA(){
        depotsA = new ArrayList<>(); // instatiates the arraylist into depotsA
        
        for(int i = 1; i <101; i++ ){   //Runs the variable i value from 1 to 101
            depotsA.add( new CompanyA(i)); // adds a new object from collection Company(A) in a possition in the array(depotsA)
        }  
        return depotsA; // returns after populating it
    }
    
   /**
     * Populates ArrayList depotsB with 100 depots from collection CompanyB
     * @return depotsB
     */
    public static List<CompanyB> addDepotsB(){
        depotsB = new ArrayList<>(); // instatiates the arraylist into depotsB
        
        for(int i = 1; i <101; i++ ){ //Runs the variable i value from 1 to 101
            depotsB.add( new CompanyB(i)); // adds a new object from collection Company(B) in a new possition in the array(depotsB)
              
        } 
        return depotsB; // returns after populating it
    }
    
    /**
     * Populates ArrayList depotsB with 100 depots from collection CompanyC
     * @return depotsC
     */
    public static List<CompanyC> addDepotsC(){
        depotsC = new ArrayList<>(); // instatiates the arraylist into depotsC
        
        for(int i = 1; i <101; i++ ){ //Runs the variable i value from 1 to 101
            depotsC.add( new CompanyC(i)); // adds a new object from collection Company(C) in a new possition in the array(depotsC)
              
        } 
        return depotsC; // returns after populating it
    }
}
