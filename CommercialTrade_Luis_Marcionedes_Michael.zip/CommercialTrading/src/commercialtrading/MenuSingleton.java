
package commercialtrading;

import java.util.Scanner;

/**
*
* Applying the design pattern: Singleton Pattern
* 
* @author Luis, Marcionedes, Michael
* @version 2.0
* @since 2018-04-11
 */

public class MenuSingleton {
    
    private static MenuSingleton instance = new MenuSingleton(); //instatiates this class into the variable instance
    
     String customerName;
     String welcome = "Welcome to Commercial Trading!";
     Scanner scanner = new Scanner(System.in); // instantiates the scanner library into the variable scanner
     
     
    /**
     * Changed to private to keep the default style of singleton pattern
     */
    private MenuSingleton(){
    }
        /**
         * 
         * @return instance
         */
        public static MenuSingleton getInstance(){
          return instance;
        }
        
    /**
     *
     */
    public void menu(){
              try{
                               System.out.println(
                               "Please type your name");
                               customerName = scanner.next(); // Stores customer's name into customerName
                               
            
            System.out.println("Please select one of the following options: "+"\n"+
                               "[1] To choose a company"+"\n"+
                               "[2] To trade autonomously" ); 
            
                               int option = scanner.nextInt(); // Stores the option selected by the user
          
            switch(option){ // Checks the variable option and directs the user to the suitable case
                case 1 :
                    
                    System.out.println("Select one of the following companies"+"\n"+
                                        "[3] Company A"+"\n"+
                                        "[4] Company B"+"\n"+
                                        "[5] Company C"
                            ); 
                    
                        int companyOption = scanner.nextInt(); // Stores the second option selected by the user
                    
                        switch(companyOption){ // nested switch which checks the variable companyOption and directs the user to the suitable case
                            
                            
                            case 3 : 
                             
                                Trade.purchaseB("A"); 
                                Trade.purchaseC("A");
                                Trade.purchaseA("B");
                                Trade.purchaseA("C");
                                Trade.purchaseB("C");
                                Trade.purchaseC("B");
                                Trade.Outputs(companyOption);
                                closeProgram();
                          
                                break; 

                            
                            case 4 : 
                                Trade.purchaseA("B");
                                Trade.purchaseC("B");
                                Trade.purchaseB("A");
                                Trade.purchaseB("C");
                                Trade.purchaseC("A");
                                Trade.purchaseA("C");
                                Trade.Outputs(companyOption);
                                closeProgram();
                                
                                break; 
                             
                               
                            case 5 : 
                                Trade.purchaseA("C");
                                Trade.purchaseB("C");
                                Trade.purchaseC("A");
                                Trade.purchaseC("B");
                                Trade.purchaseB("A");
                                Trade.purchaseA("B"); 
                                Trade.Outputs(companyOption);
                                closeProgram();
                                
                                break;
                                
                                default :
                                    menu();
                                }
                        
                    break;  
  
                case 2 :
                    Trade.purchaseB("A"); 
                    Trade.purchaseC("A");
                    Trade.purchaseA("C");
                    Trade.purchaseA("B");
                    Trade.purchaseB("C");
                    Trade.purchaseC("B");    
                    Trade.Outputs(option);
                    closeProgram();
                    
                    
                    break;
                      default :
                       menu();
            
            }
              }catch (Exception e){
                  System.err.print("Caught Exception: "+e.getMessage()+"\n \n"+"Error ocurred, program must be restarted"+"\n");
                  
 
              }
            
            
            
        }
        /**
         * 
         */
        public void closeProgram(){
            System.out.println("Would you like to close the program? [yes] / [no]"+"\n");
            String close = scanner.next(); // Stores the option selected by the user
            
           switch(close){
               case "yes":
                   System.out.println("Thanks for using Commercial Trading " + customerName );
                   System.exit(0);
                   break;
                
                case "no" :
                    menu();
                    break;
                default :
                    menu();
           }
                
        
        
        }
    
}
