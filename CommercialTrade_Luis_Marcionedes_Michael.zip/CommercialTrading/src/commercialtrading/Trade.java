package commercialtrading;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
*
* @author Luis, Marcionedes, Michael
* @version 2.0
* @since 2018-04-11
 */
public class Trade{
    static ArrayList<String> stored1 = new ArrayList<String>(); // Stores information about the transactions, to be shown in the output
    static ArrayList<String> stored2 = new ArrayList<String>();
    static ArrayList<String> stored3 = new ArrayList<String>();
    static ArrayList<String> stored4 = new ArrayList<String>();
    static ArrayList<String> stored5 = new ArrayList<String>();
    static ArrayList<String> stored6 = new ArrayList<String>();
    
    static int cashCheck; // checks if the company still have money to keep buying
    static int priceA; // Stores the total price per product from company A
    static int priceB;// Stores the total price per product from company B
    static int priceC;// Stores the total price per product from company C
    static int addStock; // Stores the transaction value when one item is added to the stock
    static int removeStock; // Stores the transaction value when one item is removed from stock
    static int cashAvailable; //Stores the allowance from the buying store after a transaction
    static int payment; // Stores the new allowance from the selling store after a transcation
   
    
    /**
     * Sells products from Depots A
     * @param company first arg
     */
    public static void purchaseA(String company){
         
            if(company.equalsIgnoreCase("B")){
           
                for(int i = 0; i < 100; i++ ){ // Loops the ArrayList depotsB
                    for(int j =0;j < 100; j++){ // Loops the ArrayList depotsA
                        
                        cashCheck = DepotFactory.depotsB.get(i).getAllowance() - (DepotFactory.depotsA.get(j).getDelivery() 
                                   +DepotFactory.depotsA.get(j).getProductCost());
                        
                    if (cashCheck < 50){ // Checks if the depot has enough cash to start the transactions
                        
                    }   else if (DepotFactory.depotsB.get(i).getStockA() >= DepotFactory.depotsB.get(i).maxP){ //Checks if the depotsB still has space to buy 
                           
                    }   else if (DepotFactory.depotsA.get(j).getStockA() < DepotFactory.depotsA.get(j).minN){// Checks if the depotsA still has products to sell
                             
                    }   else{ 
                        
                            while(DepotFactory.depotsB.get(i).getAllowance()>= 50 && 
                                DepotFactory.depotsA.get(j).getStockA() > DepotFactory.depotsA.get(j).minN  && 
                                DepotFactory.depotsB.get(i).getStockA() < DepotFactory.depotsB.get(i).maxP ){ // While the conditions are true,will keep looping
                                
                                priceA = DepotFactory.depotsA.get(j).getDelivery()
                                                   +DepotFactory.depotsA.get(j).getProductCost();
                                
                                removeStock = DepotFactory.depotsA.get(j).getStockA() -1 ;
                                DepotFactory.depotsA.get(j).setStockA(removeStock); // Sets the a new value to the Stock from depotsA
                                addStock = DepotFactory.depotsB.get(i).getStockA() + 1;
                                DepotFactory.depotsB.get(i).setStockA(addStock); // Sets the a new value to the Stock from depotsB
                                cashAvailable = DepotFactory.depotsB.get(i).getAllowance() - priceA ;
                                DepotFactory.depotsB.get(i).setAllowance(cashAvailable);// Sets a new allowance to depotsB 
                                payment = DepotFactory.depotsA.get(j).getAllowance() + priceA;
                                DepotFactory.depotsA.get(j).setAllowance(payment);// Sets a new allowance to depotsB
                                
                                stored1.add("\n"+"Depot Buying B"+DepotFactory.depotsB.get(i).id+
                                              "\n"+"Depot Selling A"+DepotFactory.depotsA.get(j).id+
                                              "\n"+"Cost of Product: "+DepotFactory.depotsA.get(j).getProductCost()+
                                              "\n"+"Cost of Delivery: "+DepotFactory.depotsA.get(j).getDelivery()+
                                              "\n"+"Total Cost of doing Business: "+priceA  );
                                
                                
                        }
                    } 
                }
            }
        }           
                    
        if(company.equalsIgnoreCase("C")){
                
                for(int i = 0; i < 100; i++ ){ // CompanyC
                    for(int j =0;j < 100; j++){ // CompanyA
                        
                        cashCheck = DepotFactory.depotsC.get(i).getAllowance() - (DepotFactory.depotsA.get(j).getDelivery() 
                                + DepotFactory.depotsA.get(j).getProductCost());
                
                    
                    if (cashCheck < 50){
                        
                    }   else if (DepotFactory.depotsC.get(i).getStockA() >= DepotFactory.depotsC.get(i).maxP){
                           
                    }   else if (DepotFactory.depotsA.get(j).getStockA() < DepotFactory.depotsA.get(j).minN){
                            
                    }   else{
                        while(DepotFactory.depotsC.get(i).getAllowance()>= 50 && 
                            DepotFactory.depotsA.get(j).getStockA() > DepotFactory.depotsA.get(j).minN  && 
                            DepotFactory.depotsC.get(i).getStockA() < DepotFactory.depotsC.get(i).maxP ){
                                
                                priceA = DepotFactory.depotsA.get(j).getDelivery()
                                        +DepotFactory.depotsA.get(j).getProductCost();
                                
                                removeStock = DepotFactory.depotsA.get(j).getStockA() -1 ;
                                DepotFactory.depotsA.get(j).setStockA(removeStock);
                                addStock = DepotFactory.depotsC.get(i).getStockA() + 1;
                                DepotFactory.depotsC.get(i).setStockA(addStock);
                                cashAvailable = DepotFactory.depotsC.get(i).getAllowance() - priceA ;
                                DepotFactory.depotsC.get(i).setAllowance(cashAvailable);
                                payment = DepotFactory.depotsA.get(j).getAllowance() + priceA;
                                DepotFactory.depotsA.get(j).setAllowance(payment);
               
                                stored2.add("\n"+"Depot Buying C"+DepotFactory.depotsC.get(i).id+
                                              "\n"+"Depot Selling A"+DepotFactory.depotsA.get(j).id+
                                              "\n"+"Cost of Product: "+DepotFactory.depotsA.get(j).getProductCost()+
                                              "\n"+"Cost of Delivery: "+DepotFactory.depotsA.get(j).getDelivery()+
                                              "\n"+"Total Cost of doing Business: "+priceA  );
                               
                        }
                    } 
                 
                  
                                
                }
            }
        }   
    }
    
    /**
     * @param company 
     */
    
    
    public static void purchaseB(String company) {
       
            if(company.equalsIgnoreCase("A")){
                
                for(int i = 0; i < 100; i++ ){ // CompanyA
                    for(int j =0;j < 100; j++){ // CompanyB
                        
                        cashCheck = DepotFactory.depotsA.get(i).getAllowance() - (DepotFactory.depotsB.get(j).getDelivery() 
                                + DepotFactory.depotsB.get(j).getProductCost());
                
                    
                    if (cashCheck < 50){
                        
                    }   else if (DepotFactory.depotsA.get(i).getStockB() >= DepotFactory.depotsA.get(i).maxP){
                         
                    }   else if (DepotFactory.depotsB.get(j).getStockB() < DepotFactory.depotsB.get(j).minN){
                             
                    }   else{
                            while(DepotFactory.depotsA.get(i).getAllowance()>= 50 && 
                                  DepotFactory.depotsA.get(i).getStockB() < DepotFactory.depotsA.get(i).maxP &&
                                  DepotFactory.depotsB.get(j).getStockB() > DepotFactory.depotsB.get(j).minN){
                                
                                priceB = DepotFactory.depotsB.get(j).getDelivery()
                                        +DepotFactory.depotsB.get(j).getProductCost();
                                
                                removeStock = DepotFactory.depotsB.get(j).getStockB() -1 ;
                                DepotFactory.depotsB.get(j).setStockB(removeStock);
                                addStock = DepotFactory.depotsA.get(i).getStockB() + 1;
                                DepotFactory.depotsA.get(i).setStockB(addStock);
                                cashAvailable = DepotFactory.depotsA.get(i).getAllowance() - priceB ;
                                DepotFactory.depotsA.get(i).setAllowance(cashAvailable);
                                payment = DepotFactory.depotsB.get(j).getAllowance() + priceB;
                                DepotFactory.depotsB.get(j).setAllowance(payment);
           
                                stored3.add("\n"+"Depot Buying A"+DepotFactory.depotsA.get(i).id+
                                              "\n"+"Depot Selling B"+DepotFactory.depotsB.get(j).id+
                                              "\n"+"Cost of Product: "+DepotFactory.depotsB.get(j).getProductCost()+
                                              "\n"+"Cost of Delivery: "+DepotFactory.depotsB.get(j).getDelivery()+
                                              "\n"+"Total Cost of doing Business: "+priceB  );
                               
                                
                        }
                    } 
                }
            }
        }                 
        
        
        
        if (company.equalsIgnoreCase("C")){
               
                for(int i = 0; i < 100; i++ ){ // CompanyC
                    for(int j =0;j < 100; j++){ // CompanyB
                        
                        cashCheck = DepotFactory.depotsC.get(i).getAllowance() - (DepotFactory.depotsB.get(j).getDelivery() 
                                + DepotFactory.depotsB.get(j).getProductCost());
                
                    
                    if (cashCheck < 50){
                        
                    }   else if (DepotFactory.depotsC.get(i).getStockB() >= DepotFactory.depotsC.get(i).maxP){
                          
                    }   else if (DepotFactory.depotsB.get(j).getStockB() < DepotFactory.depotsB.get(j).minN){
                           
                    }   else{
                        while(DepotFactory.depotsC.get(i).getAllowance()>= 50 && 
                              DepotFactory.depotsB.get(j).getStockB() > DepotFactory.depotsB.get(j).minN  && 
                              DepotFactory.depotsC.get(i).getStockB() < DepotFactory.depotsC.get(i).maxP ){

                                priceB = DepotFactory.depotsB.get(j).getDelivery()
                                                   +DepotFactory.depotsB.get(j).getProductCost();
   
                                removeStock = DepotFactory.depotsB.get(j).getStockB() -1 ;
                                DepotFactory.depotsB.get(j).setStockB(removeStock);
                                addStock = DepotFactory.depotsC.get(i).getStockB() + 1;
                                DepotFactory.depotsC.get(i).setStockB(addStock);
                                cashAvailable = DepotFactory.depotsC.get(i).getAllowance() - priceB ;
                                DepotFactory.depotsC.get(i).setAllowance(cashAvailable);
                                payment = DepotFactory.depotsB.get(j).getAllowance() + priceB;
                                DepotFactory.depotsB.get(j).setAllowance(payment);   
                       
                                stored4.add("\n"+"Depot Buying C"+DepotFactory.depotsC.get(i).id+
                                              "\n"+"Depot Selling B"+DepotFactory.depotsB.get(j).id+
                                              "\n"+"Cost of Product: "+DepotFactory.depotsB.get(j).getProductCost()+
                                              "\n"+"Cost of Delivery: "+DepotFactory.depotsB.get(j).getDelivery()+
                                              "\n"+"Total Cost of doing Business: "+priceB  );
                               
                                
                        }
                    } 
                }
            }
        }       
        
    }
    
    
    /**
     * @param Company 
     */
    public static void purchaseC(String Company){
        
            if (Company.equalsIgnoreCase("B")){ 
            
                for(int i = 0; i < 100; i++ ){ // CompanyB
                    for(int j =0;j < 100; j++){ // CompanyC
                        
                        cashCheck = DepotFactory.depotsB.get(i).getAllowance() - (DepotFactory.depotsC.get(j).getDelivery() 
                                + DepotFactory.depotsC.get(j).getProductCost());
                
                    
                    if (cashCheck < 50){
                        
                    }   else if (DepotFactory.depotsB.get(i).getStockC() >= DepotFactory.depotsB.get(i).maxP){
                           
                    }   else if (DepotFactory.depotsC.get(j).getStockC() < DepotFactory.depotsC.get(j).minN){
                             
                    }   else{
                        while(DepotFactory.depotsB.get(i).getAllowance()>= 50 && 
                            DepotFactory.depotsC.get(j).getStockC() > DepotFactory.depotsC.get(j).minN  && 
                            DepotFactory.depotsB.get(i).getStockC() < DepotFactory.depotsB.get(i).maxP ){
                                
                                priceC = DepotFactory.depotsC.get(j).getDelivery()
                                        +DepotFactory.depotsC.get(j).getProductCost();
                                
                                removeStock = DepotFactory.depotsC.get(j).getStockC() -1 ;
                                DepotFactory.depotsC.get(j).setStockC(removeStock);
                                addStock = DepotFactory.depotsB.get(i).getStockC() + 1;
                                DepotFactory.depotsB.get(i).setStockC(addStock);                                    
                                cashAvailable = DepotFactory.depotsB.get(i).getAllowance() - priceC ;
                                DepotFactory.depotsB.get(i).setAllowance(cashAvailable);
                                payment = DepotFactory.depotsC.get(j).getAllowance() + priceC;
                                DepotFactory.depotsC.get(j).setAllowance(payment);


                        
                                 stored5.add("\n"+"Depot Buying B"+DepotFactory.depotsB.get(i).id+
                                              "\n"+"Depot Selling C"+DepotFactory.depotsC.get(j).id+
                                              "\n"+"Cost of Product: "+DepotFactory.depotsC.get(j).getProductCost()+
                                              "\n"+"Cost of Delivery: "+DepotFactory.depotsC.get(j).getDelivery()+
                                              "\n"+"Total Cost of doing Business: "+priceC  );
                               
                        
                        }
                     }
                    } 
                }
            }
               
        
        if (Company.equalsIgnoreCase("A")){    
            
                for(int i = 0; i < 100; i++ ){ // CompanyA
                    for(int j =0;j < 100; j++){ // CompanyC
                        
                        cashCheck = DepotFactory.depotsA.get(i).getAllowance() - (DepotFactory.depotsC.get(j).getDelivery() 
                                + DepotFactory.depotsC.get(j).getProductCost());
                
                    
                    if (cashCheck < 50){
                        
                    }   else if (DepotFactory.depotsA.get(i).getStockC() >= DepotFactory.depotsA.get(i).maxP){
                           
                    }   else if (DepotFactory.depotsC.get(j).getStockC() < DepotFactory.depotsC.get(j).minN){
                             
                    }   else{
                        while(DepotFactory.depotsA.get(i).getAllowance()>= 50 && 
                            DepotFactory.depotsC.get(j).getStockC() > DepotFactory.depotsC.get(j).minN  && 
                            DepotFactory.depotsA.get(i).getStockC() < DepotFactory.depotsA.get(i).maxP ){
                                
                                priceC = DepotFactory.depotsC.get(j).getDelivery()
                                                   +DepotFactory.depotsC.get(j).getProductCost();

                                removeStock = DepotFactory.depotsC.get(j).getStockC() -1 ;
                                DepotFactory.depotsC.get(j).setStockC(removeStock);
                                addStock = DepotFactory.depotsA.get(i).getStockC() + 1;
                                DepotFactory.depotsA.get(i).setStockC(addStock);
                                cashAvailable = DepotFactory.depotsA.get(i).getAllowance() - priceC ;
                                DepotFactory.depotsA.get(i).setAllowance(cashAvailable);
                                payment = DepotFactory.depotsC.get(j).getAllowance() + priceC;
                                DepotFactory.depotsC.get(j).setAllowance(payment);


                                 stored6.add("\n"+"Depot Buying A"+DepotFactory.depotsA.get(i).id+
                                              "\n"+"Depot Selling C"+DepotFactory.depotsC.get(j).id+
                                              "\n"+"Cost of Product: "+DepotFactory.depotsC.get(j).getProductCost()+
                                              "\n"+"Cost of Delivery: "+DepotFactory.depotsC.get(j).getDelivery()+
                                              "\n"+"Total Cost of doing Business: "+priceC);
                               
                        }
                    }
                }
             }
        }
    }
    
    /**
     * @param Company 
     */
    
    public static void Outputs (int Company){
        switch (Company) {
            case 3:
                for(int i = 0; i < stored3.size(); i++ ){ 
                    System.out.println(stored3.get(i));
                    
                }   for(int i = 0; i < stored6.size(); i++ ){ 
                    System.out.println(stored6.get(i));
                    
                }   break;
            case 4:
                for(int i = 0; i < stored1.size(); i++ ){ 
                    System.out.println(stored1.get(i));
                    
                }   for(int i = 0; i < stored5.size(); i++ ){ 
                    System.out.println(stored5.get(i));
                    
                }   break;
            case 5:
                for(int i = 0; i < stored2.size(); i++ ){ 
                    System.out.println(stored2.get(i));
                    
                }   for(int i = 0; i < stored4.size(); i++ ){ 
                    System.out.println(stored4.get(i));
                    
                }   break;
            default:
                break;
        }
        
        
        
        
    }
}
