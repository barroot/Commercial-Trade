package commercialtrading;

/**
*
* @author Luis, Marcionedes, Michael
* @version 2.0
* @since 2018-04-11
 */
public class CommercialTrading {
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
        CommercialTradeFacade object = new CommercialTradeFacade();
        
        
       
    }
    
}
